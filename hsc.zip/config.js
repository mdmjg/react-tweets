module.exports = {
  twitter: {
    consumer_key: 'ft7oclyqk6ZG6wFd9lk8XbiGT',
    consumer_secret: 'CK7wywNoOzzCyX22kBMoGdvZGsVLTnkA5Nb5VR8filZBRfd2uB',
    access_token_key: '723810421795348480-yyw9YGs3dwcw1dnmq016bf5QQxyTXso',
    access_token_secret: '1Ak6lrR0svFerM6KAlWpO7gkdIEfuIPE1k0X2DSAd9Y68'
  }
}
